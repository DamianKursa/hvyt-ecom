const CheckoutForm = () => {
  return <div>Checkout form</div>;
};

export default CheckoutForm;
