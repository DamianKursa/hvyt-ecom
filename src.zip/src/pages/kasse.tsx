const Kasse = () => {
  return <div>Kasse Page</div>;
};

export default Kasse;
